/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg8joption;

import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        String nome = JOptionPane.showInputDialog("Digite seu nome:");

int opcao = JOptionPane.showConfirmDialog(null, "Voce é maior de idade?", "Verificação de Idade", JOptionPane.YES_NO_OPTION);

if (opcao == JOptionPane.YES_OPTION) {
    JOptionPane.showMessageDialog(null, "Bem-vindo, " + nome );
} else {
    JOptionPane.showMessageDialog(null, "Desculpe, " + nome + ", você não pode continuar");
}
    }
}


